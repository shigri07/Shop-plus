"""Store pulse: a small sales monitoring website.

Start it with:  python app.py
Then open:      http://127.0.0.1:5000
"""
from datetime import date, datetime, timedelta

from flask import Flask, jsonify, request

import database

app = Flask(__name__, static_folder="static", static_url_path="")
database.ensure_db()


def money(value):
    return "Rs " + format(round(value), ",")


def clamp(value, low, high):
    return max(low, min(high, value))


def daily_rows(conn, start, end):
    """One row per calendar day between start and end (both included)."""
    s, e = start.isoformat(), end.isoformat()
    sales = {
        r["day"]: (r["orders"], r["revenue"])
        for r in conn.execute(
            """SELECT substr(created_at, 1, 10) AS day, COUNT(*) AS orders, SUM(total) AS revenue
               FROM orders
               WHERE status != 'Refunded' AND substr(created_at, 1, 10) BETWEEN ? AND ?
               GROUP BY day""",
            (s, e),
        )
    }
    traffic = {
        r["day"]: r["sessions"]
        for r in conn.execute("SELECT day, sessions FROM daily_sessions WHERE day BETWEEN ? AND ?", (s, e))
    }
    rows, day = [], start
    while day <= end:
        key = day.isoformat()
        orders, revenue = sales.get(key, (0, 0))
        rows.append({"date": key, "orders": orders, "revenue": revenue or 0, "sessions": traffic.get(key, 0)})
        day += timedelta(days=1)
    return rows


def totals(rows):
    """Revenue, orders, average order value and conversion rate for a list of days."""
    revenue = sum(r["revenue"] for r in rows)
    orders = sum(r["orders"] for r in rows)
    sessions = sum(r["sessions"] for r in rows)
    return {
        "rev": revenue,
        "orders": orders,
        "aov": revenue / orders if orders else 0,
        "conv": orders / sessions if sessions else None,  # None means "no traffic data"
    }


def series(rows):
    per_day = [totals([r]) for r in rows]
    return {k: [p[k] if p[k] is not None else 0 for p in per_day] for k in ("rev", "orders", "aov", "conv")}


@app.get("/")
def index():
    return app.send_static_file("index.html")


@app.get("/api/dashboard")
def dashboard():
    days = request.args.get("range", 30, type=int)
    if days not in (7, 30, 90):
        days = 30
    rules = {
        "drop": clamp(request.args.get("drop", 60, type=float), 10, 95),
        "conv": clamp(request.args.get("conv", 1.8, type=float), 0.1, 10),
        "stock": clamp(request.args.get("stock", 8, type=int), 0, 1000),
        "pending": clamp(request.args.get("pending", 24, type=int), 1, 720),
    }

    end = date.today() - timedelta(days=1)          # last full day
    start = end - timedelta(days=2 * days + 7 - 1)  # this period, previous period, plus 7 days for averages
    now = datetime.now()
    conn = database.connect()

    rows = daily_rows(conn, start, end)
    view, prior = rows[-days:], rows[-2 * days:-days]

    # A day is a "dip" when revenue is below X% of the average of the 7 days before it.
    flags = []
    for i in range(len(rows) - days, len(rows)):
        trailing = rows[i - 7:i]
        average = sum(r["revenue"] for r in trailing) / 7
        flags.append(average > 0 and rows[i]["revenue"] < rules["drop"] / 100 * average)

    products = [
        dict(r) for r in conn.execute(
            """SELECT p.id, p.name, p.price, p.stock,
                      COALESCE(SUM(s.qty), 0) AS units,
                      COALESCE(SUM(s.qty * s.price), 0) AS revenue
               FROM products p
               LEFT JOIN (
                   SELECT oi.product_id, oi.qty, oi.price
                   FROM order_items oi JOIN orders o ON o.id = oi.order_id
                   WHERE o.status != 'Refunded' AND substr(o.created_at, 1, 10) BETWEEN ? AND ?
               ) s ON s.product_id = p.id
               GROUP BY p.id
               ORDER BY revenue DESC""",
            (view[0]["date"], view[-1]["date"]),
        )
    ]

    def with_age(row):
        order = dict(row)
        order["age_hours"] = int((now - datetime.fromisoformat(order["created_at"])).total_seconds() // 3600)
        return order

    recent = [
        with_age(r) for r in conn.execute(
            """SELECT number, customer, total, status, created_at FROM orders
               WHERE id IN (SELECT id FROM orders ORDER BY created_at DESC LIMIT 8)
                  OR (status = 'Pending' AND created_at >= ?)
               ORDER BY created_at DESC""",
            ((now - timedelta(days=30)).isoformat(),),
        )
    ]

    # ---- alerts ----
    alerts = []
    last = view[-1]
    average7 = sum(r["revenue"] for r in rows[-8:-1]) / 7
    if flags[-1]:
        others = sum(1 for f in flags[:-1] if f)
        detail = f"{money(last['revenue'])}, which is {round(last['revenue'] / average7 * 100)}% of the 7-day average ({money(average7)})."
        if others:
            detail += f" {others} other {'day' if others == 1 else 'days'} in this range also dipped."
        alerts.append({"urgent": True, "title": "Revenue dipped yesterday", "detail": detail,
                       "action": "Check ads, site speed and checkout."})
    if last["sessions"] and last["orders"] / last["sessions"] * 100 < rules["conv"]:
        rate = last["orders"] / last["sessions"] * 100
        alerts.append({"urgent": False, "title": "Conversion rate is low",
                       "detail": f"{rate:.2f}% yesterday, below your {rules['conv']:.1f}% rule.",
                       "action": "Test a purchase on mobile and check payment options."})
    for p in sorted((p for p in products if p["stock"] <= rules["stock"]), key=lambda p: p["stock"]):
        alerts.append({"urgent": p["stock"] <= rules["stock"] / 2, "title": f"Low stock: {p['name']}",
                       "detail": f"{p['stock']} left. Your rule is {rules['stock']} or fewer.",
                       "action": "Reorder or hide the product before it sells out."})
    late = [o for o in recent if o["status"] == "Pending" and o["age_hours"] >= rules["pending"]]
    if late:
        names = ", ".join(f"{o['number']} ({o['age_hours']} h)" for o in late)
        alerts.append({
            "urgent": any(o["age_hours"] >= rules["pending"] * 2 for o in late),
            "title": f"{len(late)} pending {'order is' if len(late) == 1 else 'orders are'} late",
            "detail": f"{names} waiting more than {rules['pending']} hours.",
            "action": "Confirm payment or contact the customer.",
        })

    conn.close()
    return jsonify({
        "range": days,
        "dates": [r["date"] for r in view],
        "series": {"cur": series(view), "prior": series(prior)},
        "kpis": {k: {"cur": totals(view)[k], "prior": totals(prior)[k]} for k in ("rev", "orders", "aov", "conv")},
        "flags": flags,
        "products": products,
        "orders": recent,
        "alerts": alerts,
    })


if __name__ == "__main__":
    app.run(debug=True)
