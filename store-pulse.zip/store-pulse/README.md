# Store pulse

A small website that monitors your store's sales. It shows revenue, orders, average order
value and conversion rate, compares them with the previous period, lists products and
stock, and raises alerts when something looks wrong.

Built with Python (Flask), SQLite and plain HTML, CSS and JavaScript. No Node.js needed.

## Run it in VS Code

1. Install **Python 3.9 or newer** (python.org) and **VS Code** with the **Python** extension.
2. In VS Code choose **File > Open Folder** and open this `store-pulse` folder.
3. Open the terminal: **Terminal > New Terminal**.
4. Create a virtual environment and install Flask:

   Windows (PowerShell):
   ```
   python -m venv .venv
   .venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   ```
   If PowerShell blocks the activate step, run
   `Set-ExecutionPolicy -Scope Process Bypass` once and try again.

   macOS or Linux:
   ```
   python3 -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```
5. Start the site:
   ```
   python app.py
   ```
6. Open http://127.0.0.1:5000 in your browser.

The first start creates `store.db` with sample data. You can also press **F5** in VS Code
to run it. If VS Code asks, pick the interpreter from `.venv`
(**Ctrl+Shift+P > Python: Select Interpreter**).

To stop the server press **Ctrl+C** in the terminal.

## Project layout

| File | What it does |
| --- | --- |
| `app.py` | The server. `/api/dashboard` calculates all numbers and alerts. |
| `database.py` | Table definitions and the sample data generator. |
| `static/index.html` | The page. |
| `static/style.css` | Colours, layout, dark mode. |
| `static/app.js` | Fetches the data and draws the chart, tables and alerts. |
| `import_shopify_csv.py` | Loads your real Shopify orders export. |
| `set_stock.py` | Sets the stock of one product. |

## Use your real Shopify data

1. In Shopify admin export your orders as CSV (Orders > Export).
2. Optional, for conversion rate: export "Sessions over time" from Analytics > Reports.
3. Run:
   ```
   python import_shopify_csv.py orders_export.csv sessions.csv
   ```
   This replaces the sample data. If the import fails with a missing column, open the CSV
   and match the names in the `COLUMNS` block at the top of the script.
4. Set real stock numbers (the orders export has no stock):
   ```
   python set_stock.py "Product name" 25
   ```
5. Restart is not needed. Refresh the page.

To get the sample data back, run `python database.py`.

## Ideas for next steps

- Connect to the Shopify Admin API so data updates by itself.
- Send alerts to WhatsApp or email (the alert list in `app.py` is the place to hook in).
- Add a login page before putting it online.
- Move from SQLite to MySQL when you need more than one user at a time.
