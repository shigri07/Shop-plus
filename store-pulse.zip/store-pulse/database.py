"""Database setup and sample data for Store pulse.

Run this file directly (python database.py) to throw away the current data
and create a fresh set of sample data.
"""
import random
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

DB_PATH = Path(__file__).parent / "store.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS products (
    id    INTEGER PRIMARY KEY AUTOINCREMENT,
    name  TEXT NOT NULL UNIQUE,
    price REAL NOT NULL,
    stock INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS orders (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    number     TEXT NOT NULL,
    customer   TEXT NOT NULL,
    total      REAL NOT NULL,
    status     TEXT NOT NULL,          -- Paid, Fulfilled, Pending, Refunded
    created_at TEXT NOT NULL           -- ISO format: 2026-10-09T14:32:10
);
CREATE TABLE IF NOT EXISTS order_items (
    order_id   INTEGER NOT NULL REFERENCES orders(id),
    product_id INTEGER NOT NULL REFERENCES products(id),
    qty        INTEGER NOT NULL,
    price      REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS daily_sessions (
    day      TEXT PRIMARY KEY,         -- 2026-10-09
    sessions INTEGER NOT NULL          -- store visits that day
);
CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at);
"""

# name, price, how often it sells (weight), units in stock
PRODUCTS = [
    ("Hunza dried apricots, 1 kg", 2400, 0.22, 46),
    ("Skardu walnuts, 500 g", 1900, 0.17, 31),
    ("Shilajit resin, 20 g", 5200, 0.12, 9),
    ("Gilgit wool shawl", 7800, 0.08, 17),
    ("Balti herbal tea, 100 g", 850, 0.20, 58),
    ("Apricot kernel oil, 100 ml", 2900, 0.10, 4),
    ("Hand-knit wool cap", 1500, 0.07, 12),
    ("Pashmina scarf", 9500, 0.04, 6),
]

CUSTOMERS = [
    "Ayesha K.", "Hamza R.", "Sana M.", "Bilal A.", "Zainab H.", "Imran S.",
    "Mehwish T.", "Faisal D.", "Noor U.", "Tariq B.", "Hira N.", "Usman G.",
    "Maryam L.", "Asad J.", "Rabia P.", "Kamran W.",
]


def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def reset_schema(conn):
    conn.executescript(
        "DROP TABLE IF EXISTS order_items;"
        "DROP TABLE IF EXISTS orders;"
        "DROP TABLE IF EXISTS products;"
        "DROP TABLE IF EXISTS daily_sessions;"
    )
    conn.executescript(SCHEMA)


def seed(days=190):
    """Fill the database with believable sample data ending today."""
    rng = random.Random(52807)
    now = datetime.now().replace(microsecond=0)
    midnight = now.replace(hour=0, minute=0, second=0)

    conn = connect()
    reset_schema(conn)
    conn.executemany(
        "INSERT INTO products (name, price, stock) VALUES (?, ?, ?)",
        [(n, p, s) for n, p, _, s in PRODUCTS],
    )
    prices = {i + 1: p[1] for i, p in enumerate(PRODUCTS)}
    ids = list(prices)
    weights = [p[2] for p in PRODUCTS]
    weekday_boost = [0.85, 0.95, 1.0, 1.05, 1.2, 1.15, 0.9]  # Monday first

    placed = []     # one dict per order
    sessions = []   # (day, visits)
    for ago in range(days - 1, -1, -1):
        day = midnight - timedelta(days=ago)
        progress = (days - 1 - ago) / days
        if ago == 0:  # today: only a few orders so far
            minutes_so_far = now.hour * 60 + now.minute
            count = rng.randint(2, 6) if minutes_so_far >= 60 else 0
            latest_minute = max(minutes_so_far, 1)
        else:
            base = 16 * weekday_boost[day.weekday()] * (1 + progress * 0.35)
            count = round(base * (0.86 + rng.random() * 0.28))
            conversion = 0.021 + rng.random() * 0.007
            if ago == 1:  # make yesterday a bad day so the alerts have something to show
                count = round(count * 0.5)
                conversion = 0.0155
            sessions.append((day.strftime("%Y-%m-%d"), round(count / conversion)))
            latest_minute = None
        for _ in range(count):
            minute = rng.randint(0, latest_minute) if latest_minute else rng.randint(8 * 60, 22 * 60)
            wanted = 1 if rng.random() < 0.8 else 2
            chosen = set(rng.choices(ids, weights, k=wanted))
            items = [(pid, 1 if rng.random() < 0.9 else 2, prices[pid]) for pid in chosen]
            placed.append({
                "ts": day + timedelta(minutes=minute),
                "customer": rng.choice(CUSTOMERS),
                "items": items,
            })

    placed.sort(key=lambda o: o["ts"])
    for o in placed:
        age = (now - o["ts"]).total_seconds() / 3600
        r = rng.random()
        if age > 72:
            o["status"] = "Fulfilled" if r < 0.90 else "Refunded" if r < 0.95 else "Paid"
        else:
            o["status"] = "Paid" if r < 0.70 else "Fulfilled" if r < 0.98 else "Pending"

    def closest_to(hours):
        return min(placed, key=lambda o: abs((now - o["ts"]).total_seconds() / 3600 - hours))

    for h in (5, 31, 52):
        closest_to(h)["status"] = "Pending"
    closest_to(38)["status"] = "Refunded"

    for n, o in enumerate(placed, start=1001):
        total = sum(q * p for _, q, p in o["items"])
        cur = conn.execute(
            "INSERT INTO orders (number, customer, total, status, created_at) VALUES (?, ?, ?, ?, ?)",
            (f"#{n}", o["customer"], total, o["status"], o["ts"].isoformat()),
        )
        conn.executemany(
            "INSERT INTO order_items (order_id, product_id, qty, price) VALUES (?, ?, ?, ?)",
            [(cur.lastrowid, pid, q, p) for pid, q, p in o["items"]],
        )
    conn.executemany("INSERT INTO daily_sessions (day, sessions) VALUES (?, ?)", sessions)
    conn.commit()
    conn.close()
    print(f"Created {len(placed)} sample orders in {DB_PATH.name}")


def ensure_db():
    if not DB_PATH.exists():
        seed()


if __name__ == "__main__":
    seed()
