"""Change the stock of one product.

Example:  python set_stock.py "Pashmina scarf" 25
"""
import sys

import database

if len(sys.argv) != 3:
    sys.exit('Usage: python set_stock.py "Product name" 25')

conn = database.connect()
cur = conn.execute("UPDATE products SET stock = ? WHERE name = ?", (int(sys.argv[2]), sys.argv[1]))
conn.commit()
print("Updated." if cur.rowcount else "No product with that exact name. Check the spelling.")
