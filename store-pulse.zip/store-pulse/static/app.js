(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);

  // ---------- state ----------
  let range = 30;
  let metric = "rev";
  let orderFilter = "All";
  let hover = null;
  let data = null;      // last response from /api/dashboard
  let geo = null;       // chart geometry, used by the hover code
  let requestId = 0;
  const rules = { drop: 60, conv: 1.8, stock: 8, pending: 24 };

  // ---------- formatting ----------
  const group = (v) => Math.round(v).toLocaleString("en-US");
  const rs = (v) => "Rs " + group(v);
  const short = (v) => (v >= 1e6 ? (v / 1e6).toFixed(1) + "M" : v >= 1e3 ? Math.round(v / 1e3) + "k" : String(Math.round(v)));
  const toDate = (iso) => new Date(iso + "T00:00:00");
  const dayLabel = (iso) => toDate(iso).toLocaleDateString("en-GB", { day: "numeric", month: "short" });

  const METRICS = {
    rev:    { label: "Revenue", title: "Revenue per day", fmt: rs, axis: (v) => "Rs " + short(v), zero: true },
    orders: { label: "Orders", title: "Orders per day", fmt: group, axis: (v) => String(Math.round(v)), zero: true },
    aov:    { label: "Average order value", title: "Average order value per day", fmt: rs, axis: group, zero: false },
    conv:   { label: "Conversion rate", title: "Conversion rate per day", fmt: (v) => (v * 100).toFixed(2) + "%", axis: (v) => (v * 100).toFixed(1) + "%", zero: false },
  };
  const ORDER = ["rev", "orders", "aov", "conv"];

  // ---------- loading ----------
  async function load() {
    const id = ++requestId;
    const params = new URLSearchParams({ range, drop: rules.drop, conv: rules.conv, stock: rules.stock, pending: rules.pending });
    try {
      const res = await fetch("/api/dashboard?" + params);
      if (!res.ok) throw new Error("server answered " + res.status);
      const json = await res.json();
      if (id !== requestId) return;   // a newer request is already on its way
      data = json;
      $("error").hidden = true;
      renderAll();
    } catch (err) {
      $("error").textContent = "Could not load the data. Is the server running? (" + err.message + ")";
      $("error").hidden = false;
    }
  }

  // ---------- KPIs ----------
  function renderKPIs() {
    let html = "";
    ORDER.forEach((key) => {
      const m = METRICS[key];
      const { cur, prior } = data.kpis[key];
      let text, cls;
      if (cur === null || prior === null) {
        text = "No traffic data"; cls = "flat";
      } else if (key === "conv") {
        const d = (cur - prior) * 100;
        text = (d >= 0 ? "\u25B2 +" : "\u25BC ") + d.toFixed(2) + " pp vs previous " + range + " days"; cls = d >= 0 ? "up" : "down";
      } else if (prior === 0) {
        text = "No previous data"; cls = "flat";
      } else {
        const d = (cur / prior - 1) * 100;
        text = (d >= 0 ? "\u25B2 +" : "\u25BC ") + d.toFixed(1) + "% vs previous " + range + " days"; cls = d >= 0 ? "up" : "down";
      }
      html += '<button type="button" class="kpi" data-m="' + key + '" aria-pressed="' + (key === metric) + '">' +
        '<span class="k-label">' + m.label + "</span>" +
        '<span class="k-val">' + (cur === null ? "n/a" : m.fmt(cur)) + "</span>" +
        '<span class="k-delta ' + cls + '">' + text + "</span></button>";
    });
    $("kpis").innerHTML = html;
    $("chartTitle").textContent = METRICS[metric].title;
  }

  // ---------- chart ----------
  function drawChart() {
    const W = Math.max($("chartBox").clientWidth - 16, 300);
    const H = 300;
    const m = { t: 14, r: 14, b: 30, l: W < 520 ? 46 : 62 };
    const def = METRICS[metric];
    const cur = data.series.cur[metric];
    const pri = data.series.prior[metric];
    const n = cur.length;

    let hi = Math.max(...cur, ...pri);
    let lo = Math.min(...cur, ...pri);
    lo = def.zero ? 0 : lo - (hi - lo) * 0.15;
    if (hi === lo) hi = lo + 1;
    hi = hi + (hi - lo) * 0.08;

    const x = (i) => m.l + (W - m.l - m.r) * (n === 1 ? 0 : i / (n - 1));
    const y = (v) => m.t + (H - m.t - m.b) * (1 - (v - lo) / (hi - lo));

    let svg = '<svg viewBox="0 0 ' + W + " " + H + '" width="' + W + '" height="' + H + '" aria-hidden="true">';
    for (let j = 0; j <= 4; j++) {
      const v = lo + ((hi - lo) * j) / 4;
      const yy = y(v);
      svg += '<line x1="' + m.l + '" x2="' + (W - m.r) + '" y1="' + yy + '" y2="' + yy + '" stroke="var(--line)"/>';
      svg += '<text x="' + (m.l - 8) + '" y="' + (yy + 4) + '" text-anchor="end" font-size="12" fill="var(--muted)">' + def.axis(v) + "</text>";
    }
    const ticks = W < 520 ? 3 : 5;
    for (let q = 0; q < ticks; q++) {
      const idx = Math.round((q * (n - 1)) / (ticks - 1));
      const anchor = q === 0 ? "start" : q === ticks - 1 ? "end" : "middle";
      svg += '<text x="' + x(idx) + '" y="' + (H - 8) + '" text-anchor="' + anchor + '" font-size="12" fill="var(--muted)">' + dayLabel(data.dates[idx]) + "</text>";
    }
    const path = (arr) => arr.map((v, i) => (i ? "L" : "M") + x(i).toFixed(1) + "," + y(v).toFixed(1)).join(" ");
    svg += '<path d="' + path(cur) + " L" + x(n - 1) + "," + y(lo) + " L" + x(0) + "," + y(lo) + ' Z" fill="var(--accent-soft)" opacity="0.7"/>';
    svg += '<path d="' + path(pri) + '" fill="none" stroke="var(--prior)" stroke-width="2" stroke-dasharray="5 4"/>';
    svg += '<path d="' + path(cur) + '" fill="none" stroke="var(--accent)" stroke-width="2.5" stroke-linejoin="round"/>';
    data.flags.forEach((flagged, k) => {
      if (flagged) svg += '<circle cx="' + x(k) + '" cy="' + y(cur[k]) + '" r="5" fill="var(--bad)" stroke="var(--surface)" stroke-width="2"/>';
    });
    svg += '<line id="hl" x1="0" x2="0" y1="' + m.t + '" y2="' + (H - m.b) + '" stroke="var(--ink)" opacity="0.35" visibility="hidden"/>';
    svg += '<circle id="hc" r="5" fill="var(--accent)" stroke="var(--surface)" stroke-width="2" visibility="hidden"/></svg>';

    const host = $("svgHost");
    host.innerHTML = svg;
    geo = { x, y, n, cur, pri, W, m };

    host.onpointermove = (e) => {
      const box = host.firstChild.getBoundingClientRect();
      const px = (e.clientX - box.left) * (W / box.width);
      const i = Math.round(((px - m.l) / (W - m.l - m.r)) * (n - 1));
      setHover(Math.max(0, Math.min(n - 1, i)));
    };
    host.onpointerleave = () => setHover(null);
    setHover(hover !== null && hover < n ? hover : null);
  }

  function setHover(i) {
    hover = i;
    const line = $("hl"), dot = $("hc"), tip = $("tip");
    if (!line) return;
    if (i === null) {
      line.setAttribute("visibility", "hidden");
      dot.setAttribute("visibility", "hidden");
      tip.classList.remove("on");
      return;
    }
    const def = METRICS[metric];
    const px = geo.x(i);
    line.setAttribute("x1", px); line.setAttribute("x2", px);
    dot.setAttribute("cx", px); dot.setAttribute("cy", geo.y(geo.cur[i]));
    line.setAttribute("visibility", "visible"); dot.setAttribute("visibility", "visible");
    const when = toDate(data.dates[i]).toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" });
    tip.innerHTML = "<b>" + when + "</b><br>" + def.label + ": " + def.fmt(geo.cur[i]) +
      "<br>Same day, previous period: " + def.fmt(geo.pri[i]) +
      (data.flags[i] ? "<br><b>Revenue dip</b>" : "");
    tip.style.left = Math.min(Math.max(px + 8, 110), geo.W - 110) + "px";
    tip.classList.add("on");
  }

  // ---------- tables ----------
  function renderProducts() {
    let html = '<tr><th>Product</th><th class="num">Sold</th><th class="num">Revenue</th><th class="num">In stock</th></tr>';
    data.products.forEach((p) => {
      const low = p.stock <= rules.stock;
      html += "<tr><td>" + p.name + '</td><td class="num">' + group(p.units) + '</td><td class="num">' + rs(p.revenue) + "</td>" +
        '<td class="num"><span class="stockCell"><span class="' + (low ? "low-txt" : "") + '">' + p.stock + (low ? " (low)" : "") + "</span>" +
        '<span class="bar' + (low ? " low" : "") + '"><i style="width:' + Math.min(100, (p.stock / 60) * 100) + '%"></i></span></span></td></tr>';
    });
    $("prod").innerHTML = html;
  }

  function renderOrders() {
    let html = '<tr><th>Order</th><th>Customer</th><th class="num">Total</th><th>Status</th><th class="num">Age</th></tr>';
    data.orders
      .filter((o) => orderFilter === "All" || o.status === orderFilter)
      .forEach((o) => {
        const late = o.status === "Pending" && o.age_hours >= rules.pending;
        html += "<tr><td>" + o.number + "</td><td>" + o.customer + '</td><td class="num">' + rs(o.total) + "</td>" +
          '<td><span class="pill ' + o.status + '">' + o.status + "</span></td>" +
          '<td class="num ' + (late ? "late" : "") + '">' + o.age_hours + " h" + (late ? " (late)" : "") + "</td></tr>";
      });
    $("ord").innerHTML = html;
  }

  // ---------- alerts ----------
  function renderAlerts() {
    const list = data.alerts;
    $("alerts").innerHTML = list.length
      ? list.map((a) =>
          '<li class="alert' + (a.urgent ? " bad" : "") + '"><span class="lvl">' + (a.urgent ? "Urgent" : "Watch") + "</span>" +
          "<strong>" + a.title + "</strong><p>" + a.detail + '</p><p class="act">' + a.action + "</p></li>").join("")
      : '<li class="empty">All clear. No rule is triggered right now. Change a rule below to see an alert appear.</li>';
    const badge = $("count");
    badge.textContent = list.length;
    badge.className = "count" + (list.length ? "" : " zero");
  }

  function renderAll() {
    renderKPIs();
    drawChart();
    renderProducts();
    renderOrders();
    renderAlerts();
  }

  // ---------- controls ----------
  function setPressed(container, attr, value) {
    container.querySelectorAll("button").forEach((b) => b.setAttribute("aria-pressed", String(b.getAttribute(attr) === String(value))));
  }

  $("range").addEventListener("click", (e) => {
    const b = e.target.closest("button");
    if (!b) return;
    range = Number(b.dataset.r);
    hover = null;
    setPressed($("range"), "data-r", range);
    load();
  });

  $("kpis").addEventListener("click", (e) => {
    const b = e.target.closest(".kpi");
    if (!b) return;
    metric = b.dataset.m;
    renderKPIs();
    drawChart();
    document.querySelector('.kpi[data-m="' + metric + '"]').focus();
  });

  $("chips").addEventListener("click", (e) => {
    const b = e.target.closest("button");
    if (!b) return;
    orderFilter = b.dataset.f;
    setPressed($("chips"), "data-f", orderFilter);
    renderOrders();
  });

  $("chartBox").addEventListener("keydown", (e) => {
    if (!data || (e.key !== "ArrowLeft" && e.key !== "ArrowRight")) return;
    e.preventDefault();
    const n = data.dates.length;
    const next = hover === null ? n - 1 : hover + (e.key === "ArrowRight" ? 1 : -1);
    setHover(Math.max(0, Math.min(n - 1, next)));
  });

  let timer;
  function bindRule(id, key, format, isFloat) {
    const input = $("r-" + id), out = $("o-" + id);
    const update = () => {
      rules[key] = isFloat ? parseFloat(input.value) : parseInt(input.value, 10);
      out.textContent = format(rules[key]);
    };
    input.addEventListener("input", () => {
      update();
      clearTimeout(timer);
      timer = setTimeout(load, 150);
    });
    update();
  }
  bindRule("drop", "drop", (v) => v + "%", false);
  bindRule("conv", "conv", (v) => v.toFixed(1) + "%", true);
  bindRule("stock", "stock", (v) => v + " units", false);
  bindRule("pending", "pending", (v) => v + " hours", false);

  // ---------- theme ----------
  const root = document.documentElement;
  const isDark = () => root.dataset.theme === "dark" || (!root.dataset.theme && window.matchMedia("(prefers-color-scheme: dark)").matches);
  const themeButton = $("theme");
  const updateThemeLabel = () => { themeButton.textContent = isDark() ? "Light mode" : "Dark mode"; };
  themeButton.addEventListener("click", () => {
    root.dataset.theme = isDark() ? "light" : "dark";
    updateThemeLabel();
  });
  updateThemeLabel();

  let resizeTimer;
  window.addEventListener("resize", () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => data && drawChart(), 120);
  });

  load();
})();
