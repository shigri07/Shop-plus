"""Replace the sample data with your real Shopify orders.

1. In Shopify admin: Orders > Export > "All orders" > CSV for Excel, plain CSV file.
2. Optional, for conversion rate: Analytics > Reports > Sessions over time > Export as CSV.
3. Run:
       python import_shopify_csv.py orders_export.csv
       python import_shopify_csv.py orders_export.csv sessions.csv

This DELETES the sample data first. Stock is not part of the orders export, so new
products start at 999 units. Set real numbers with set_stock.py.

Column names are taken from Shopify's standard export. If your file uses different
names, change the strings in COLUMNS below.
"""
import csv
import sys

import database

COLUMNS = {
    "number": "Name",
    "created": "Created at",
    "total": "Total",
    "financial": "Financial Status",
    "fulfillment": "Fulfillment Status",
    "cancelled": "Cancelled at",
    "billing_name": "Billing Name",
    "email": "Email",
    "item_name": "Lineitem name",
    "item_qty": "Lineitem quantity",
    "item_price": "Lineitem price",
}


def to_status(row):
    financial = (row.get(COLUMNS["financial"]) or "").lower()
    if row.get(COLUMNS["cancelled"]) or financial in ("refunded", "voided"):
        return "Refunded"          # cancelled and refunded orders are not counted as sales
    if financial in ("pending", "authorized"):
        return "Pending"
    if (row.get(COLUMNS["fulfillment"]) or "").lower() == "fulfilled":
        return "Fulfilled"
    return "Paid"


def to_iso(text):
    # Shopify writes "2026-10-01 14:32:10 +0500". Keep the store's local time.
    return text[:19].replace(" ", "T")


def number(text, default=0.0):
    try:
        return float((text or "").replace(",", ""))
    except ValueError:
        return default


def import_orders(conn, path):
    orders = {}
    with open(path, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            key = row.get(COLUMNS["number"])
            if not key:
                continue
            if key not in orders:   # order-level columns are only filled on the first row of an order
                orders[key] = {
                    "created": to_iso(row.get(COLUMNS["created"]) or ""),
                    "total": number(row.get(COLUMNS["total"])),
                    "status": to_status(row),
                    "customer": row.get(COLUMNS["billing_name"]) or row.get(COLUMNS["email"]) or "Unknown",
                    "items": [],
                }
            name = row.get(COLUMNS["item_name"])
            if name:
                orders[key]["items"].append(
                    (name, int(number(row.get(COLUMNS["item_qty"]), 1)), number(row.get(COLUMNS["item_price"])))
                )

    product_ids = {}
    for key, o in sorted(orders.items(), key=lambda kv: kv[1]["created"]):
        if not o["created"]:
            continue
        cur = conn.execute(
            "INSERT INTO orders (number, customer, total, status, created_at) VALUES (?, ?, ?, ?, ?)",
            (key, o["customer"], o["total"], o["status"], o["created"]),
        )
        for name, qty, price in o["items"]:
            if name not in product_ids:
                conn.execute("INSERT OR IGNORE INTO products (name, price, stock) VALUES (?, ?, 999)", (name, price))
                product_ids[name] = conn.execute("SELECT id FROM products WHERE name = ?", (name,)).fetchone()[0]
            conn.execute(
                "INSERT INTO order_items (order_id, product_id, qty, price) VALUES (?, ?, ?, ?)",
                (cur.lastrowid, product_ids[name], qty, price),
            )
    return len(orders)


def import_sessions(conn, path):
    count = 0
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        day_col = next(c for c in reader.fieldnames if "day" in c.lower() or "date" in c.lower())
        sess_col = next(c for c in reader.fieldnames if "session" in c.lower())
        for row in reader:
            conn.execute(
                "INSERT OR REPLACE INTO daily_sessions (day, sessions) VALUES (?, ?)",
                (row[day_col][:10], int(number(row[sess_col]))),
            )
            count += 1
    return count


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    conn = database.connect()
    database.reset_schema(conn)
    print("Imported", import_orders(conn, sys.argv[1]), "orders")
    if len(sys.argv) > 2:
        print("Imported", import_sessions(conn, sys.argv[2]), "days of traffic")
    conn.commit()
    conn.close()
